import mongoose, { Schema } from "mongoose";

const MODEL_NAME = "Product";

const schema = new Schema(
  {
    title: String,
    text: String,
    link: String,
    imgUrl: String,
    alt: String,
    shortdesc: String,
    desc: String,
    price: String,
    createdAt: Date,
    updateAt: Date,
  },
  {
    timestamps: true,
  }
);

export default mongoose.models[MODEL_NAME] ||
  mongoose.model(MODEL_NAME, schema, "products");
